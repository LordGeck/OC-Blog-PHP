-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : sam. 27 mars 2021 à 17:30
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `php_blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `creation_date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `header_content` text NOT NULL,
  `main_content` text NOT NULL,
  `user_username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `title`, `creation_date`, `update_date`, `header_content`, `main_content`, `user_username`) VALUES
(6, 'Lorem ipsum dolor sit amet', '2021-03-27 17:24:36', '2021-03-27 17:24:36', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi posuere maximus nisi non tempus. Fusce hendrerit viverra velit vitae egestas.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi posuere maximus nisi non tempus. Fusce hendrerit viverra velit vitae egestas. Ut odio libero, mollis ullamcorper tincidunt vitae, sagittis at diam. Vivamus vulputate et orci vel accumsan. Cras porta tempus varius. Donec diam dolor, lacinia et tortor ut, volutpat lacinia nulla. Integer sit amet nisl augue. Morbi vitae viverra arcu. Mauris tempus ultricies mi, at molestie turpis ullamcorper sed. Duis elementum turpis nibh, vel ullamcorper justo aliquam sed. Donec rhoncus magna sit amet aliquet ultrices. Vivamus eu tempus odio, id vehicula arcu. Donec at placerat diam. Vestibulum molestie tincidunt accumsan.\r\n\r\nVivamus ut commodo turpis, quis consectetur mi. Nulla imperdiet lorem ac dictum aliquet. Aenean lobortis egestas malesuada. Maecenas nec faucibus nisl. Quisque vitae sollicitudin ex. Etiam tincidunt, lectus ut finibus auctor, nunc magna pellentesque diam, et iaculis libero neque id lacus. Phasellus vel laoreet velit, lacinia faucibus purus. Nulla dignissim libero eget eros pretium lacinia.\r\n\r\nVestibulum nec nibh purus. Vivamus vel ligula sagittis diam faucibus fringilla sed sit amet arcu. In hac habitasse platea dictumst. Aliquam ipsum risus, dignissim maximus laoreet ut, pulvinar quis magna. Donec non sagittis justo. Aenean varius dictum elit, vel mollis libero posuere eu. Ut sagittis ex mi, sed mollis massa eleifend et. Quisque vel porttitor elit.\r\n\r\nQuisque dignissim, est a ornare euismod, dui odio hendrerit nisi, eget bibendum libero odio ac magna. Maecenas ultrices orci orci, sit amet eleifend risus faucibus eu. Ut vitae luctus ligula. Fusce venenatis urna nibh, sit amet molestie est euismod eu. Donec a nunc diam. Morbi id elementum justo. Donec at velit nulla. In ex turpis, sodales id congue et, commodo id eros. Etiam elementum feugiat erat, eget pellentesque lorem luctus vel. In hac habitasse platea dictumst. Curabitur semper sapien ut lectus accumsan venenatis.\r\n\r\nProin tristique ornare velit eu rhoncus. Suspendisse id eros varius quam efficitur facilisis id et odio. Cras ultricies eleifend ligula in scelerisque. Etiam pellentesque erat in dictum malesuada. Donec nunc sem, hendrerit eget nisi quis, porttitor posuere lectus. Sed ultricies quam feugiat hendrerit facilisis. Vivamus vitae tortor sed quam pulvinar fringilla. Mauris id pulvinar metus, id condimentum erat. Sed pellentesque eleifend convallis. In tempor, nisl sed dictum pulvinar, diam tortor auctor nisl, sed tempor ante eros a tellus. Fusce vitae mollis eros. In sagittis placerat tempus. Phasellus lacinia turpis gravida tellus tempus, id faucibus ligula vestibulum. Vivamus ut nulla non nibh tincidunt luctus sit amet ac diam. Mauris at ultrices diam. ', 'Lordgeck'),
(7, 'Sed bibendum, nulla ut laoreet sagittis', '2021-03-27 17:27:51', '2021-03-27 17:27:51', 'Sed bibendum, nulla ut laoreet sagittis, risus augue accumsan purus, eget malesuada urna magna vel leo.', ' Sed bibendum, nulla ut laoreet sagittis, risus augue accumsan purus, eget malesuada urna magna vel leo. Phasellus vitae pretium libero. Nunc tincidunt quis dolor at viverra. Suspendisse eleifend nec erat sit amet pellentesque. Sed finibus justo sed quam vulputate semper. Etiam varius, eros vitae mattis aliquam, ligula erat ornare sapien, in efficitur lacus ipsum et mauris. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Mauris eget dui iaculis, iaculis libero at, tempor odio. Vivamus dolor nulla, fringilla sit amet sodales et, cursus sit amet elit. Maecenas aliquet sit amet urna eu accumsan. Vestibulum ex libero, rutrum eget sollicitudin ac, pellentesque ac urna. Nulla mollis velit ipsum, eu feugiat dolor rhoncus ac. Nulla in quam enim. Vivamus pretium est nec eleifend ultrices.\r\n\r\nPellentesque efficitur vestibulum tortor ac porttitor. Suspendisse venenatis at risus ut ullamcorper. Nam eu auctor dolor. Nunc ullamcorper sodales justo, sed dignissim justo efficitur a. Pellentesque lacus elit, gravida eget lacus et, ullamcorper scelerisque nunc. Maecenas tristique neque eget hendrerit porta. Fusce a elementum felis, at aliquet elit. Donec commodo feugiat sollicitudin. Nulla facilisi. Sed ultrices diam viverra ultrices semper. Fusce eu leo sed turpis mollis vestibulum. Phasellus vitae tortor ultricies, molestie sem et, aliquet velit. In hac habitasse platea dictumst. Maecenas elementum enim neque, in commodo augue pulvinar in. Nulla magna sem, mattis a leo non, luctus blandit dolor. Curabitur convallis ullamcorper bibendum.\r\n\r\nSed eu ullamcorper lacus, semper dapibus eros. Quisque interdum suscipit lectus ac tempor. Fusce consectetur erat id enim vestibulum vulputate. Quisque tincidunt leo ut nibh dapibus, non faucibus sapien pharetra. Cras maximus, diam a aliquet dictum, nisi odio lobortis ipsum, vitae lobortis dui quam vitae nisl. Mauris blandit sapien sed elit laoreet, eget finibus nulla consequat. Integer eget risus elementum justo ultricies sagittis. Nunc sodales malesuada ipsum, at lacinia ante lacinia ut. ', 'Lordgeck');

-- --------------------------------------------------------

--
-- Structure de la table `post_comments`
--

CREATE TABLE `post_comments` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'PENDING',
  `creation_date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `content` text NOT NULL,
  `blog_post_id` int(11) NOT NULL,
  `user_username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `post_comments`
--

INSERT INTO `post_comments` (`id`, `status`, `creation_date`, `update_date`, `content`, `blog_post_id`, `user_username`) VALUES
(11, 'PUBLISHED', '2021-03-27 17:26:22', '2021-03-27 17:26:22', 'Test', 6, 'Lordgeck');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'STANDARD'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`username`, `email`, `firstname`, `lastname`, `password_hash`, `role`) VALUES
('Lordgeck', 'lordgeck@gmail.com', 'Hyacinthe', 'Bres', '$2y$10$LTK4B/W8kZy2EFJ9YjRn3.d4XkXToWrVXNeSOKSawMjbOTWsJTw/S', 'ADMIN');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_blog_posts_fk` (`user_username`);

--
-- Index pour la table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_posts_post_comments_fk` (`blog_post_id`),
  ADD KEY `users_post_comments_fk` (`user_username`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `users_idx` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD CONSTRAINT `users_blog_posts_fk` FOREIGN KEY (`user_username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `blog_posts_post_comments_fk` FOREIGN KEY (`blog_post_id`) REFERENCES `blog_posts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `users_post_comments_fk` FOREIGN KEY (`user_username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
